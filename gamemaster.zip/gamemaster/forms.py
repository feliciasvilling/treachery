from django.contrib.auth.forms import AuthenticationForm
from django import forms
from django.forms.models import BaseModelFormSet
from django.forms import ModelForm
from players.models import *
from django.forms import *
import django.forms
